import visitor.*;

public class SecondVisitor extends GJDepthFirst {

}
