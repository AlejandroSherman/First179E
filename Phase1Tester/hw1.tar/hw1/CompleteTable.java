//this will store the entire class symbol table for the program

public class CompleteTable extends AbstractTable {
    CompleteTable(){
        Global = new SymbolTable();
    }
}
