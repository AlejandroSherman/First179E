//TypeTable indentifies: class or method (and typetable?)

public class TypeTable extends AbstractTable{
    
    public 
    
    //new TypeTable("main", classID)
    //new TypeTable("main", classID, argTable.Global);
    //new TypeTable(n.f0.f0.which, argTable.MethodName, argTable.ClassName, argTable.Global);

    TypeTable(String methodName, String className){
        //need to understand if methodName or Type
        //also what this table even does
    }

    TypeTable(String methodName, String className, SymbolTable Global){

    }

    TypeTable(Integer grammerChoice, String methodName, String className, SymbolTable Global){

    }
}
